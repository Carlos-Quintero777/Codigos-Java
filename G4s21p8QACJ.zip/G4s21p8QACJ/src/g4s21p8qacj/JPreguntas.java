package g4s21p8qacj;


public class JPreguntas {
    
    String[] preguntas = {
        "¿QUIEN ES EL PADRE DE LA QUIMICA?", "¿QUE SIGNIFICA MEXICO?", "¿EN QUE AÑO COMIENZA LA SEGUNDA GUERRA MUNDIAL?",
        "¿QUIEN ES ESCRIBIÓ EL ANTICRISTO?", "¿QUIEN CREO EL LSD?"
    };
    
   public String getPregunta(int posicion){
        return preguntas[posicion];
    }
    
}
