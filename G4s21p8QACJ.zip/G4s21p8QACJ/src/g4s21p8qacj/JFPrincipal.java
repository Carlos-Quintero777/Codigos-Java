package g4s21p8qacj;

import examenpaquete.JFExamen;

public class JFPrincipal {

   
    public static void main(String[] args) {
       
     new JFExamen().setVisible(true);
        
    }
}
