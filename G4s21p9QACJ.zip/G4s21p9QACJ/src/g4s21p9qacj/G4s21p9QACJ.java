/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g4s21p9qacj;

/**
 *
 * @author tesoem
 */
public class G4s21p9QACJ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new JFPrincipal().setVisible(true);
    }
    
}
